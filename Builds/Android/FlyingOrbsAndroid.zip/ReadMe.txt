Collect all red orbs
Red orbs replenish energy
Controllers:
  -Tap screen with two fingers to create radial force from the player position
  -Press screen to use hock in order to create a force to change direction